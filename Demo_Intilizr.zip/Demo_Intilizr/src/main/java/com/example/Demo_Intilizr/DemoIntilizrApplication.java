package com.example.Demo_Intilizr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoIntilizrApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoIntilizrApplication.class, args);
	}

}
