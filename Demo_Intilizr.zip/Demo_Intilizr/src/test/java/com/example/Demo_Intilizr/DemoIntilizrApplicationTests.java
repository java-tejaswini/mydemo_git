package com.example.Demo_Intilizr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoIntilizrApplicationTests {

	@Test
	void contextLoads() {
	}

}
